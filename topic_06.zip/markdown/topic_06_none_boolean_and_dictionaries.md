<style>
  .line-container {
    position: relative;
    margin-left: 0px; /* spacing from other elements */
    margin-right: 0px;
    margin-top: 20px;
    margin-bottom: 20px;
  }
  .horizontal-line {
    height: 2px; /* Line thickness */
    background-color: blue; /* Line color */
    width: 100%; /* Full width line */
  }
  .top-box {
    width: 10px; /* Box width */
    height: 10px; /* Box height */
    background-color: red; /* Box color */
    position: absolute;
    top: 100%; /* Position just below the line */
    left: 0; /* Align to the left side */
    margin-top: 0px; /* Optional spacing between line and box */
  }
  .bottom-box {
    width: 10px; /* Box width */
    height: 10px; /* Box height */
    background-color: red; /* Box color */
    position: absolute;
    bottom: 100%; /* Position just below the line */
    right: 0%; /* Align to the left side */
    margin-top: 0px; /* Optional spacing between line and box */
  }
</style>
<style>
  .definition-box {
    width: 100%;
    border: 2px solid navy;
    border-radius: 5px;
    overflow: hidden;
  }
  .definition-header {
    background-color: navy;
    color: white;
    padding: 10px;
    font-weight: bold;
    font-size: 52px;
  }
  .definition-body {
    background-color: white;
    color: navy;
    padding: 15px;
    line-height: 2.0;
    text-align: justify;
    font-size: 52px;
  }
</style>


<div style="background-color: black; padding: 20px; border-radius: 40px;">
  <h1 style="font-size: 82px; font-weight: bold; text-align: center; line-height: 2.0; margin: 0; color: orange;">🖥️ Fundamentals of Programming</h1>
  <h1 style="font-size: 72px; font-weight: bold; text-align: center; line-height: 2.0; margin: 0; color: orange;">📝 Dictionaries, Boolean, and None Data Types</h1>
  <h1 style="font-size: 72px; font-weight: bold; text-align: center; line-height: 2.0; margin: 0; color: red;">🎓 Dr. Aamir Alaud Din</h1>
  <h1 style="font-size: 72px; font-weight: bold; text-align: center; line-height: 2.0; margin: 0; color: green;">🗓️ August 30, 2025</h1>
</div>
<br><br><br>

<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">Contents</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ol type="1">
    <li>Recap</li>
    <li>Objectives</li>
    <li>The Why Section</li>
    <li>Dictionaries</li>
    <li>Boolean Data Type</li>
    <li>None Data Type</li>
    <li>Summary</li>
    <li>Exercises</li>
  </ol>
</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">1. Recap</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>A list is a collection of data/variables enclosed within square brackets and the data/variables in the list are called elements of the list. The elements are separated by commas and indices are assigned to list elements by python. The list elements may be of same or different data types.</li>
    <li>List elements are accessed by indexing and slicing.</li>
    <li>Range function in Python generates a sequence of integers.</li>
    <li>1 to 3 input arguments can be passed to range function.</li>
    <li>A tuple is a collection of immutable data/variables enclosed within parentheses and the data/variables in tuple are called elements of the tuple. The elements are separated by commas and indices are assigned to tuple elements by Python. The tuple elements may be of same or different data types.</li>
    <li>A string is text data whose rules for slicing and indexing are the same as those for lists.</li>
    <li>List, range, tuple, and string methods help to perform different operations related to them.</li>
  </ul>
</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">2. Objectives</h2>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;">After <span style="color: green;">taking this lecture</span> and <span style="color: red;">studying</span>, you should be able to:</p>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Define dictionaries, describe its advantage over lists, and use them.</li>
    <li>Explain and use <code style="background-color: #f5f2f0; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">boolean</code> data type in Python.</li>
    <li>Explain and use <code style="background-color: #f5f2f0; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">None</code> data type in Python.</li>
  </ul>
</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">3. The Why Section</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Python has lists to store data, e.g., data of student scores in a subject in a list.</li>
    <li>Suppose, there are ten students in Fundamentals of Programming and their scores are stored in list as shown below.</li>
  </ul>
</div>

<span style="font-size: 45px;">

```python
scores = [95, 84, 91, 72, 80, 91, 77, 88, 90, 81]
```

</span>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>How to find the score of Muhammad Hashir?</li>
    <li>We need two facts to fetch the score of Muhammad Hashir:</li>
    <div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
      <ol style="1">
        <li>Position of score of Muhammad Hashir in the list, say 6<sup>th</sup> location with index 5.</li>
        <li>Use index notation to fetch the score from the list like <code style="background-color: #f5f2f0; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">scores[5]</code>.</li>
      </ol>
    </div>
    <li>In Python, is there any facility to fetch the scores like <code style="background-color: #f5f2f0; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">scores['Muhammad Hashir']</code>?</li>
    <li>One reason of studying this topic is to see what type of data or structure allows us to fetch data like <code style="background-color: #f5f2f0; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">scores['Muhammad Hashir']</code>.</li>
    <li>In daily life, our decisions are based on the true or false outcome of a proposition.</li>
    <li>For example, if I have Rs. 3,500/= I will eat pizza.</li>
    <li>We can write the above statement mathematically as</li>
  </ul>
</div>

<span style="font-size: 52px; line-height: 2.0;">
$$
\text{If, }money \ge 3500 \text{ is } True \text{, eat pizza}
$$
</span>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Is there any <code style="background-color: #f5f2f0; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">True</code> and <code style="background-color: #f5f2f0; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">False</code> data type in Python to make decisions in programs?</li>
    <li>Our second reason of studying this topic is to study the data type which is <code style="background-color: #f5f2f0; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">True</code> and <code style="background-color: #f5f2f0; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">False</code> to take decisions in Python programs.</li>
    <li>In figure below, we see the data of daily temperatures recorded by a device with one missing value.</li>
    <li>If Python reads the data, what data type will store this missing value?</li>
    <li>Our last reason of studying this topic is to learn the data type which handles missing data.</li>
  </ul>
</div>

<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0601.png" width="70%" alt="missing"><br><br>
  <figcaption style="font-size: 52px; line-height: 2.0; text-align: center;"><strong>Figure 1.</strong> A spreadsheet program containing daily tempeatures of a city with one missing value.</figcaption>
</figure><br>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">4. Dictionaries</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>First we define Python dictionaries.</li>
  </ul>
</div>

<br>
<div class="definition-box">
  <div class="definition-header">Definition: Dictionaries</div>
  <div class="definition-body">
    A dictionary in Python is a built-in data type that stores data as key–value pairs.
    <div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
      <ul style="list-style-type:disc">
        <li>Each key is unique and acts like an identifier.</li>
        <li>Each value is associated with a key.</li>
        <li>Dictionaries are unordered (Python 3.6+ maintains insertion order, but conceptually order is not guaranteed).</li>
        <li>Dictionaries are mutable (you can add, change, or remove items).</li>
      </ul>
    </div>
  </div>
</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Let's define a dictionary.</li>
  </ul>
</div>

<span style="font-size: 45px;">

```python
manager = {"Name": "Muhammad Zeeshan", "Age": 50, "Position": "Manager", "Employee ID": 2545, "Office Extension": 4251, "Address": "XYZ Sector Islamabad"}
```

</span>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>If we want to fetch the manager's employee ID and his address, we can use the following Python statements.</li>
  </ul>
</div>


<span style="font-size: 45px;">

```python
print(manager['Employee ID'])
print(manager['Address'])
```

</span>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The output of the above Python statements is given below.</li>
  </ul>
</div>

<span style="font-size: 45px;">

```c#
2545
'XYZ Sector Islamabad'
```

</span>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Calls to multiple keys is also possible as shown below.</li>
  </ul>
</div>

<span style="font-size: 45px;">

```python
print(manager['Name'], manager['Office Extension'])
```

</span>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The output of the above call is as follows.</li>
  </ul>
</div>

<span style="font-size: 45px;">

```c#
Muhammad Zeeshan 4251
```

</span>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>While printing dictionary elements, use of escape character or concatenation of two strings with the use of <code style="background-color: #f5f2f0; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">+</code> operation will generate a bug report.</li>
    <li>Such operations and concatenation, however, are possible with f-string printing.</li>
    <li>As an example, consider the following Python statements.</li>
  </ul>
</div>

<span style="font-size: 45px;">

```python
print(f"The data is as follows.\nName: {manager['Name']}\nAge: {manager['Age']}")
```

</span>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The output of the above statement is given below.</li>
  </ul>
</div>

<span style="font-size: 45px;">

```c#
The data is as follows.
Name: Muhammad Zeeshan
Age: 50
```

</span>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>If a dictionary has two or multiple same keys, the last key-value pair is remembered by Python.</li>
    <li>It will be clear with the following example.</li>
  </ul>
</div>

<span style="font-size: 45px;">

```python
scores = {"Hashir": 82, "Shaheer": 92, "Hashir": 88, "Fatimah": 98}
print(scores['Hashir'])
```

</span>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The output of the above statements is as follows.</li>
  </ul>
</div>

<span style="font-size: 45px;">

```c#
88
```

</span>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>So, keys in the dictionaries must be unique.</li>
    <li>The following dictionary shows how to use dictionary as a database.</li>
  </ul>
</div>

<span style="font-size: 45px;">

```python
employees = {"EMP001": {"name": "Dr. Aamir Alaud Din", "age": 46, "department": "SCEE"},
"EMP002": {"name": "Dr. Shanawar Hamid", "age": 48, "department": "SINES"}}
print(employees["EMP002"]["department"])
```

</span>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The output of above lines of Python code is given below.</li>
  </ul>
</div>

<span style="font-size: 45px;">

```c#
SINES
```

</span>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">5. Boolean Data Type</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Boolean data type is a data type that can hold only two possible values</li>
    <div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
      <ol style="1">
        <li>True (Yes, 1, On)</li>
        <li>False (No, 0, Off)</li>
      </ol>
    </div>
    <li>It is used in computer programs in decision making.</li>
    <li>The simplest way to check boolean output of a statement is shown below.</li>
  </ul>
</div>

<span style="font-size: 45px;">

```python
print(6 > 3)
```

</span>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The output of above statement is as follows.</li>
  </ul>
</div>

<span style="font-size: 45px;">

```c#
True
```

</span>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Similarly, the statement for False outcome will be <code style="background-color: #f5f2f0; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">print(3 > 6)</code>.</li>
    <li>To understand decision making in computer programs, first we look a mathematics example.</li>
  </ul>
</div>

<span style="font-size: 52px; line-height: 2.0;">
$$
If,\;\;0 \lt \theta \lt 90
$$
</span>

<span style="font-size: 52px; line-height: 2.0;">
$$
x > 0\;\;\text{and}\;\; y > 0
$$
</span>

<span style="font-size: 52px; line-height: 2.0;">
$$
If, \;\; 90 \lt \theta \lt 180
$$
</span>

<span style="font-size: 52px; line-height: 2.0;">
$$
x < 0\;\;\text{and}\;\; y > 0
$$
</span>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>In the computer programs, similar statements are used as per the Python's syntax rules.</li>
    <li>In the computer program, if angle in the program is 72<sup>o</sup>, the output will be <code style="background-color: #f5f2f0; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">True</code> for $0 \lt \theta \lt 90$ but <code style="background-color: #f5f2f0; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">False</code> for $90 \lt \theta \lt 180$.</li>
    <li>Boolean data type is always a part of approximately all professional computer programs.</li>
    <li>So, practicing it is important.</li>
  </ul>
</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">6. None Data Type</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Consider the figure shown in the why section of this topic.</li>
    <li>There was one blank cell holding no number at all.</li>
    <li>Such empty data in Python is referred to as None data type.</li>
    <li>Consider the following two Python statements.</li>
  </ul>
</div>

<span style="font-size: 45px;">

```python
x = 5
y = None
```

</span>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The variable <code style="background-color: #f5f2f0; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">x</code> hold 5 in it while <code style="background-color: #f5f2f0; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">y</code> is empty variable holding nothing at all.</li>
    <li>In data analysis project, such <code style="background-color: #f5f2f0; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">None</code> data values are replaced with either mean or some other number e.g., 0 decided for model accuracy and validation.</li>
    <li>For example in PARAFAC model, replacing missing data with 0s boosts code efficiency.</li>
    <li>The None values must be replaced carefully after consultation or left as it is if decided.</li>
  </ul>
</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">7. Summary</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Dictionaries are key-value pairs stored within curly brackets.</li>
    <li>Dictionaries enable calling data from dictionary by its key instead of its index.</li>
    <li>Dictionaries can also be used as database.</li>
    <li>Boolean data type is a data type which has only two values which are True and False.</li>
    <li>Boolean data type is used in decision making in computer programs.</li>
    <li>None data type holds no value and is used to handle missing values/data in data.</li>
  </ul>
</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">8. Exercises</h2>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Exercise 1</h3>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;">Define a dictionary of your class with student ID as key and name is values. Print the names of your 5 friends using thier IDs as keys.</p>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Exercise 2</h3>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;">Develop a database of SCEE (IESE) environmental engineering faculty database. Assign keys yourself and store their following data.</p>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ol type="A">
    <li>Full Name</li>
    <li>Room Number</li>
    <li>Cadre</li>
    <li>Highest Qualification</li>
    <li>City of Birth</li>
  </ol>
</div>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;">Print any required data from this database and verify its correct output.</p>

<h3 style="font-size: 62px; font-weight: bold; color: red; line-height: 2.0; text-align: justify;">Note</h3>

<p style="color: red; font-size: 52px; line-height: 2.0; text-align: justify;">CR is advised to collect required data and disseminate among the class.</p>
