<style>
  .line-container {
    position: relative;
    margin-left: 0px; /* spacing from other elements */
    margin-right: 0px;
    margin-top: 20px;
    margin-bottom: 20px;
  }
  .horizontal-line {
    height: 2px; /* Line thickness */
    background-color: blue; /* Line color */
    width: 100%; /* Full width line */
  }
  .top-box {
    width: 10px; /* Box width */
    height: 10px; /* Box height */
    background-color: red; /* Box color */
    position: absolute;
    top: 100%; /* Position just below the line */
    left: 0; /* Align to the left side */
    margin-top: 0px; /* Optional spacing between line and box */
  }
  .bottom-box {
    width: 10px; /* Box width */
    height: 10px; /* Box height */
    background-color: red; /* Box color */
    position: absolute;
    bottom: 100%; /* Position just below the line */
    right: 0%; /* Align to the left side */
    margin-top: 0px; /* Optional spacing between line and box */
  }
</style>
<style>
  .definition-box {
    width: 100%;
    border: 2px solid navy;
    border-radius: 5px;
    overflow: hidden;
  }
  .definition-header {
    background-color: navy;
    color: white;
    padding: 10px;
    font-weight: bold;
    font-size: 52px;
  }
  .definition-body {
    background-color: white;
    color: navy;
    padding: 15px;
    line-height: 2.0;
    text-align: justify;
    font-size: 52px;
  }
</style>

<br><br><br><br><br><br><br>
<div style="background-color: black; padding: 20px; border-radius: 40px;">
  <h1 style="font-size: 82px; font-weight: bold; text-align: center; line-height: 2.0; margin: 0; color: orange;">🖥️ Fundamentals of Programming</h1>
  <h1 style="font-size: 72px; font-weight: bold; text-align: center; line-height: 2.0; margin: 0; color: orange;">📝 Python Operators for Scientific Computing</h1>
  <h1 style="font-size: 72px; font-weight: bold; text-align: center; line-height: 2.0; margin: 0; color: red;">🎓 Dr. Aamir Alaud Din</h1>
  <h1 style="font-size: 72px; font-weight: bold; text-align: center; line-height: 2.0; margin: 0; color: green;">🗓️ August 31, 2025</h1>
</div>
<br><br><br><br><br><br><br><br><br><br><br><br>

<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">Contents</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ol type="1">
    <li>Recap</li>
    <li>Objectives</li>
    <li>The Why Section</li>
    <li>Python Operators</li>
    <li>Comparison (Relational) Operators</li>
    <li>Logical Operators</li>
    <li>Membership Operators</li>
    <li>Identity Operators</li>
    <li>Python Operators Precedence</li>
    <li>Summary</li>
    <li>Exercises</li>
  </ol>
</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">1. Recap</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Dictionaries are key-value pairs stored within curly brackets.</li>
    <li>Dictionaries enable calling data from dictionary by its key instead of its index.</li>
    <li>Dictionaries can also be used as database.</li>
    <li>Boolean data type is a data type which has only two values which are True and False.</li>
    <li>Boolean data type is used in decision making in computer programs.</li>
    <li>None data type holds no value and is used to handle missing values/data in data.</li>
  </ul>
</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">2. Objectives</h2>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;">After <span style="color: green;">taking this lecture</span> and <span style="color: red;">studying</span>, you should be able to:</p>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Define and explain operators in Python.</li>
    <li>Explain comparison operators in Python and use them.</li>
    <li>Explain logical operators in Python and use them.</li>
    <li>Explain membership operators in Python and use them.</li>
    <li>Explain identity operators in Python and use them.</li>
    <li>Know the operators precedence and tell the outcome without writing a computer program.</li>
  </ul>
</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">3. The Why Section</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>You can tell the outcome of a comparison without writing a computer program.</li>
    <li>For example if the output of <code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">6*3 < 2*8</code> is asked, you will say that the output is <code style="background-color: #f5f2f0; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">False</code>.</li>
    <li>Now, if the output of the following python statement (without calling package which is an upcoming topic and the statemet is generated for $e^{sin \theta} + x^2 \gt tan \theta + x^{cos \theta}$) is asked, what will be your answer?</li>
  </ul>
</div>

<span style="font-size: 45px;">

```python
math.exp(math.sin(theta)) + x**2 > math.tan(theta) + x**(math.cos(theta))
```

</span>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Our first reason of studying this topic is to learn how to use such statements in the programs.</li>
    <li>Now, consider the following two Python statements.</li>
  </ul>
</div>

<span style="font-size: 45px;">

```python
print(67 > 27 or 67 < 27 and 67 < 27)
print(67 > 27 and 67 < 27 or 67 < 27)
```

</span>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The result of these two lines is given below.</li>
  </ul>
</div>

<br>
<span style="font-size: 45px;">

```c#
True
False
```

</span>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>By just swapping <code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">and</code> with <code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">or</code>, the result changes.</li>
    <li>The second reason of studying this topic is to understand the usage of operators like <code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">and</code> and <code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">or</code> operator.</li>
    <li>Suppose, we have a list of 1,000,000 floats and we want to check whether the number -978.331 is in the list or not.</li>
    <li>The third reason of studying this topic is to learn the method of knowing if a variable/data is part of a list, tuple, or sequence or not.</li>
    <li>Now, consider the following Python statements.</li>
  </ul>
</div>

<br>
<span style="font-size: 45px;">

```python
a = [1, 2, 3, 4, 5]
b = [1, 2, 3, 4, 5]
c = a

print(a is c)
print(a is b)
```

</span>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The output of the above code is given below.</li>
  </ul>
</div>

<br>
<span style="font-size: 45px;">

```c#
True
False
```

</span>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Why do we see an unexpected result?</li>
    <li>The last reason of studying this topic is to know what is the criteria of two variables being the same or not.</li>
  </ul>
</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">4. Python Operators</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>First we define Python operators.</li>
  </ul>
</div>

<br>
<div class="definition-box">
  <div class="definition-header">Definition: Python Operators</div>
  <div class="definition-body">
    Python operators are special symbols used to perform specific operations on one or more operands. The variables, values, or expressions can be used as operands.
  </div>
</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>For example, Python's addition operator (+) is used to perform addition operations on two variables, values, or expressions.</li>
  </ul>
</div>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Terminologies</h3>

<h3 style="font-size: 52px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Unary Operators:</h3>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Python operators that require one operand to perform a specific operation are known as unary operators.</li>
  </ul>
</div>

<h3 style="font-size: 52px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Binary Operators</h3>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Python operators that require two operands to perform a specific operation are known as binary operators.</li>
  </ul>
</div>

<h3 style="font-size: 52px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Operands</h3>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Variables, values, or expressions that are used with the operator to perform a specific operation.</li>
  </ul>
</div>

<h3 style="font-size: 52px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Examples</h3>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>In the statement <code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">-2</code>, minus sign is unary operator and 2 is the operand.</li>
    <li>In the statement <code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">2 > 3</code>, the symbol <code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">></code> is the operator and the numbers 2 and 3 are operands.</li>
    <li>We have already covered arithmetic and assignmet operators in detail, so we will cover other operators.</li>
    <li>The result of all the operators is a boolean output which is either <code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">True</code> or <code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">False</code>.</li>
    <li>Now, we are in a position to understand the operators after having been known about the terminologies.</li>
  </ul>
</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">5. Comparison (Relational) Operators</h2>

<br>
<div class="definition-box">
  <div class="definition-header">Definition: Python Comparison Operators</div>
  <div class="definition-body">
    Python Comparison operators compare the values on either side of them and decide the relation among them. They are also called Relational operators.
  </div>
</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The following table contains all comparison operators with their symbols, names, and examples.</li>
    <li>The table is generated with the assignments shown below.</li>
  </ul>
</div>

<br>
<span style="font-size: 45px;">

```python
a = 10
b = 20
```

</span><br>

<div style="font-size: 52px;">

|Operator|Name|Example|Result|
|:---|:---|:---|:---|
|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">==</code>|Equal|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">a==b</code>|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">False</code>|
|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">!=</code>|Not Equal|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">a!=b</code>|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">True</code>|
|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">></code>|Greater Than|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">a>b</code>|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">False</code>|
|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;"><</code>|Less Than|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">a<b</code>|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">True</code>|
|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">>=</code>|Greater Than OR Equal To|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">a>=b</code>|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">False</code>|
|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;"><=</code>|Less Than OR Equal To|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">a<=b</code>|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">True</code>|

</div>


<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">6. Logical Operators</h2>

<br>
<div class="definition-box">
  <div class="definition-header">Definition: Python Logical Operators</div>
  <div class="definition-body">
    Python logical operators are used to combile two or more conditions and check the final result. There are following logical operators supported by Python language.
  </div>
</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The following table contains all logical operators with their symbols, names, and examples.</li>
    <li>The table is generated with the assignments shown below.</li>
  </ul>
</div>


<span style="font-size: 45px;">

```python
a = 10
b = 20
```

</span><br>

<div style="font-size: 52px;">

|Operator|Name|Example|Result|
|:---|:---|:---|:---|
|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">and</code>|And|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">a < b and b >= a</code>|True|
|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">or</code>|Or|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">b < a or b <= a</code>|False|
|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">not</code>|Not|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">not b > a</code>|False|

</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The following truth table is used to compute the output.</li>
  </ul>
</div>

<div style="font-size: 52px;">

|Input 1| Logical Operator |Input 2|Result|
|:---|:---|:---|:---|
|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">True</code>|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">and</code>|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">True</code>|True|
|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">True</code>|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">and</code>|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">False</code>|False|
|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">False</code>|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">and</code>|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">False</code>|False|
|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">False</code>|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">or</code>|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">False</code>|False|
|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">False</code>|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">or</code>|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">True</code>|True|
|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">True</code>|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">or</code>|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">True</code>|True|

</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Logical <code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">not</code> inverts the result.</li>
    <li>This time we use following Python program to understand it.</li>
  </ul>
</div>

<span style="font-size: 45px;">

```python
a = 10
b = 20
print(not a < b)
print(not b < a)
```

</span>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The output of the above program is given below.</li>
  </ul>
</div>


<span style="font-size: 45px;">

```c#
False
True
```

</span>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">7. Membership Operators</h2>

<br>
<div class="definition-box">
  <div class="definition-header">Definition: Python Membership Operators</div>
  <div class="definition-body">
    Python's membership operators test for membership in a sequence, such as strings, lists, or tuples.
  </div>
</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>There are two membership operators in Python which are <code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">in</code> and <code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">not in</code>.</li>
    <li>To understand it, consider the following list and variable in following Python statements and then we use the table to understand it.</li>
  </ul>
</div>

<br>
<span style="font-size: 45px;">

```python
a = 8
b = 9
lst = [0, 2, 4, 6, 8, 10]
```

</span>

<div style="font-size: 52px;">

|Operator|Description|Example|Result|
|:---|:---|:---|:---|
|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">in</code>|Returns True if it finds a variable in the specified sequence, false otherwise.|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">a in lst</code>|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">True</code>|
|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">not in</code>|Returns True if it does not finds a variable in the specified sequence and false otherwise.|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">b not in lst</code>|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">True</code>|

</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">8. Identity Operators</h2>

<br>
<div class="definition-box">
  <div class="definition-header">Definition: Python Identity Operators</div>
  <div class="definition-body">
    Python identity operators compare the memory locations of two objects.
  </div>
</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>We understand it with following Python program and the table afterwards.</li>
  </ul>
</div>

<br>
<span style="font-size: 45px;">

```python
a = [1, 2, 3, 4, 5]
b = [1, 2, 3, 4, 5]
c = a
```

</span>

<div style="font-size: 52px;">

|Operator|Description|Example|Result|
|:---|:---|:---|:---|
|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">is</code>|Returns True if both variables are the same object and false otherwise.|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">a is b</code>|False|
|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">is not</code>|Returns True if both variables are not the same object and false otherwise.|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">a is not b</code>|True|

</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>For a more clear understanding we understand it with the help of following Python program figure.</li>
  </ul>
</div>

<br>
<span style="font-size: 45px;">

```python
x = 5
y = x
print(x, y)
x = 9
print(x, y)
```

</span>

<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0701.png" width="80%" alt="fig7"><br><br>
  <figcaption style="font-size: 52px; line-height: 2.0; text-align: center;"><strong>Figure 1.</strong> Diagramatic illustration of Python Identity Operators.</figcaption>
</figure><br>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Now, we are able to write the output of the above program.</li>
  </ul>
</div>

<br>
<span style="font-size: 45px;">

```c#
5, 5
9, 5
```

</span>

<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">9. Python Operaters Precedence</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Operators precedence decides the order of the evaluation in which an operator is evaluated.</li>
    <li>Python operators have different levels of precedence.</li>
    <li>The following table contains the list of operators having highest to lowest precedence</li>
  </ul>
</div>

<div style="font-size: 52px;">

|Operator|Description|
|:---|:---|
|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">()</code>|Parentheses|
|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">**</code>|Exponentiation|
|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">+x, -x</code>|Unary Plus and Unary Minus|
|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">*, /, //, %</code>|Multiplication, Division, Floor Division, and Modulus|
|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">+, -</code>|Addition and Subtraction|
|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">==, !=, >, >=, <, <=, is, is not, in, not in</code>|Comparison, Identity, and Membership|
|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">not</code>|Logical NOT|
|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">and</code>|Logical AND|
|<code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">or</code>|Logical OR|

</div>

<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">10. Summary</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Python operators are special symbols used to perform specific operations on one or more operands. The variables, values, or expressions can be used as operands.</li>
    <li>Python Comparison operators compare the values on either side of them and decide the relation among them. They are also called Relational operators.</li>
    <li>Python logical operators are used to combile two or more conditions and check the final result.</li>
    <li>Python's membership operators test for membership in a sequence, such as strings, lists, or tuples.</li>
    <li>Python identity operators compare the memory locations of two objects.</li>
    <li>Operators precedence decides the order of the evaluation in which an operator is evaluated.</li>
  </ul>
</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Python operators are special symbols used to perform specific operations on one or more operands. The variables, values, or expressions can be used as operands.</li>
    <li>Python Comparison operators compare the values on either side of them and decide the relation among them. They are also called Relational operators.</li>
    <li>Python logical operators are used to combile two or more conditions and check the final result.</li>
    <li>Python's membership operators test for membership in a sequence, such as strings, lists, or tuples.</li>
    <li>Python identity operators compare the memory locations of two objects.</li>
    <li>Operators precedence decides the order of the evaluation in which an operator is evaluated.</li>
  </ul>
</div>

<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">11. Exercises</h2>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Exercise 1</h3>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;">Verify all the operators for the numbers -2 and 5.</p>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Exercise 2</h3>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;">Verify all the operators for the corresponding elements in the lists [7, -15] and [20, -25].</p>
