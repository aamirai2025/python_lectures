def gen_table(m, n):
    print("<span style=\"font-size: 52px; line-height: 2.0;\">\n")
    for j in range(2):
        if j == 0:
            for i in range(n + 1):
                print("|", end="")
            print()
        elif j == 1:
            for i in range(n):
                if i < n+1:
                    print("|:---", end="")
            print("|")
    for j in range(m):
        for i in range(n+1):
            print("|", end="")
        print()
    print()
    print("</span>")

gen_table(5, 3)