print("Program exits if enterd score is negative or more than 100.")
score = float(input("Enter student's score: "))

while score >= 0 and score <= 100:	
	if score > 90:
		print("A Grade")
	elif score > 80:
		print("B+ Grade")
	elif score > 70:
		print("B Grade")
	elif score > 60:
		print("C+ Grade")
	elif score > 50:
		print("C Grade")
	elif score > 40:
		print("D Grade")
	else:
		print("F Grade")
	score = float(input("Enter student's score: "))