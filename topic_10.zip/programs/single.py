import math as m
x = [-1.2600, 0.1198, -4.8391, -4.8223, -0.9673, 2.9251]
index = 0
while index < len(x):
	if x[index] > 0:
		print(x[index], m.log(x[index]))
	index += 1