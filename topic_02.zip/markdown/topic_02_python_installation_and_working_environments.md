<style>
  .line-container {
    position: relative;
    margin-left: 0px; /* spacing from other elements */
    margin-right: 0px;
    margin-top: 20px;
    margin-bottom: 20px;
  }
  .horizontal-line {
    height: 2px; /* Line thickness */
    background-color: blue; /* Line color */
    width: 100%; /* Full width line */
  }
  .top-box {
    width: 10px; /* Box width */
    height: 10px; /* Box height */
    background-color: red; /* Box color */
    position: absolute;
    top: 100%; /* Position just below the line */
    left: 0; /* Align to the left side */
    margin-top: 0px; /* Optional spacing between line and box */
  }
  .bottom-box {
    width: 10px; /* Box width */
    height: 10px; /* Box height */
    background-color: red; /* Box color */
    position: absolute;
    bottom: 100%; /* Position just below the line */
    right: 0%; /* Align to the left side */
    margin-top: 0px; /* Optional spacing between line and box */
  }
  .definition-box {
    width: 100%;
    border: 2px solid navy;
    border-radius: 5px;
    overflow: hidden;
  }
  .definition-header {
    background-color: navy;
    color: white;
    padding: 10px;
    font-weight: bold;
    font-size: 52px;
  }
  .definition-body {
    background-color: white;
    color: navy;
    padding: 15px;
    line-height: 2.0;
    text-align: justify;
    font-size: 52px;
  }
</style>
<div style="background-color: black; padding: 20px; border-radius: 40px;">
  <h1 style="font-size: 82px; font-weight: bold; text-align: center; line-height: 2.0; margin: 0; color: orange;">🖥️ Fundamentals of Programming</h1>
  <h1 style="font-size: 72px; font-weight: bold; text-align: center; line-height: 2.0; margin: 0; color: orange;">📝 Python Installation and Working Environments</h1>
  <h1 style="font-size: 72px; font-weight: bold; text-align: center; line-height: 2.0; margin: 0; color: red;">🎓 Dr. Aamir Alaud Din</h1>
  <h1 style="font-size: 72px; font-weight: bold; text-align: center; line-height: 2.0; margin: 0; color: green;">📅 September 9, 2025</h1>
</div>
<br><br><br>

<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">Contents</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ol type="1">
    <li>Recap</li>
    <li>Objectives</li>
    <li>The Why Section</li>
    <li>Philosophy of Free and Open Source Software</li>
    <li>Python, Python Packages, and Installers</li>
    <li>Python Working Environments</li>
    <li>Summary</li>
    <li>Exercises</li>
  </ol>
</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">1. Recap</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Computers, because of their efficiency, performing complex computations, and generalization of programs are used in scientific computation.</li>
    <li>Computer programming converts human understandable code to machine code for the computers and machine code to human readable format for user.</li>
    <li>Python program is a collection of instructions in the form of alphanumeric characters while python is the software installed in your computer to convert python program to machine code.</li>
    <li>Since machine code is hard to code, so we need to learn python programming and write instructions for the computers in a python program and hand it over to python for the rest of the job.</li>
    <li>Python is encompassing the most important parts of data, science, engineering, and IT, therefore, is an important programming language.</li>
  </ul>
</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">2. Objectives</h2>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;">After <span style="color: green;">taking this lecture</span> and <span style="color: red;">studying</span>, you should be able to:</p>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Describe the philosophy of proprietary and free and open source software (FOSS), in your own words.</li>
    <li>Describe the reason of various installers of python and which installer to use, in your own words.</li>
    <li>Describe, in your own words, the reason of different working environments and select any one for your future use.</li>
  </ul>
</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">3. The Why Section</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>For famous scientific software like MATLAB, Mathematica, and AutoCAD, there is only one installer provided by the company.</li>
    <li>Each of these software have built in packages e.g., MATLAB has many packages like linear algebra package, statistics package, and differential equations solver package.</li>
    <li>The installer provided by the company not only installs the main software but also installs all the packages.</li>
    <li>Although, python also provides the official installer which install python but not the packages.</li>
    <li>There are many installers of python.</li>
    <li><span style="color: blue;">One reason of studying this topic is to know why are there so many installers of Python and which one to download and install.</span></li>
    <li><span style="color: blue;">The second reason of studying this topic is to know why are there so many packages in Python.</span></li>
    <li>Just like the installer, the working environment of MATLAB is designed in such a way that the code editor (the file where we write the code), the file explorer (where folders and files are listed), the output window (where we see the results of computations), and many such facilities are available in a single window and <a href="https://www.mathworks.com/help/matlab/matlab_env/change-the-desktop-layout.html" target="_blank">click here to see</a>.</li>
    <li>But, in case of python, different working environments are available to work in python.</li>
    <li><span style="color: blue;">The third and final reason of studying this topic is to know why are there so many different working environments in Python and which one to use.</span></li>
  </ul>
</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">4. Philosophy of Free and Open Source Software</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul type="list-style-type:disc">
    <li>A proprietary software is developed by a company like Microsoft and Mathworks etc.</li>
    <li>To develop a software</li>
    <ul style="list-style-type:circle">
      <li>Experts are hired by the company.</li>
      <li>Packages, algorithms, and codes are decided by the experts.</li>
      <li>Graphic designers develop the graphical user interface (GUI).</li>
      <li>Final product is released in the market for sale.</li>
      <li>Marketing team works on promotion of the software.</li>
    </ul>
  </ul>
</div>

<br>
<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0201.png" width="65%" alt="proprietary"><br><br>
  <figcaption style="font-size: 52px; line-height: 2.0; text-align: center;"><strong>Figure 1.</strong> Philosophy of the development of proprietary software.</figcaption>
</figure>
<br>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Now we discuss the Free and Open Source Sofware (FOSS).</li>
    <ul style="list-style-type:circle">
      <li>Main/Core team develops the main software and its versions.</li>
      <li>Any University/Organization can pick main software and modifies it and releases as modified software.</li>
      <li>Any University/Organization can pick main or modified software from main team or another University/Organization and modifies it and releases as another modified software.</li>
      <li>Another University/Organization develops packages for main or modified software.</li>
      <li>Different universities and organizations work on different modified versions and packages and release the version of their own.</li>
      <li>Packages are independent codes and can be used within main/modified software.</li>
      <li>This is how there are many versions of a software and its relevant packages in the community.</li>
      <li>This is also the reason that same computation in multiple packages exist e.g., trigonometric fuctions are available in <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">math</code>, <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">numpy</code>, and <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">scipy</code> packages.</li>
      <li>Linux is best example of FOSS, <a href="https://en.wikipedia.org/wiki/Linux_distribution" target="_blank">click here to see</a> it.</li>
    </ul>
  </ul>
</div>

<br>
<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0202.png" width="75%" alt="foss"><br><br>
  <figcaption style="font-size: 52px; line-height: 2.0; text-align: center;"><strong>Figure 2.</strong> Software development by FOSS community.</figcaption>
</figure>
<br>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">5. Python, Python Packages, and Installers</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul type="list-style-type:disc">
    <li>Main Python code and its versions are released by Python Software Foundation (PSF).</li>
    <li><a href="https://www.python.org/psf-landing/" target="_blank">Click here</a> to see PSF website and its download links.</li>
    <li>Hundreds of packages are available for use with Python.</li>
    <ul style="list-style-type:circle">
      <li>Standar library packages are developed and provided by PSF along with main release.</li>
      <li>Community packages are developed by universities, organizations, and individuals.</li>
    </ul>
    <li>Python Package Index (PyPI) is the repository for packages <a href="https://pypi.org/" target="_blank">click here</a> to see packages repository.</li>
    <li>If you develop your package, you can also submit to PyPI.</li>
    <li>At PyPI majority of packages are available but not all.</li>
    <li>Anaconda, also famous as operating system of artificial intelligence, provides Python and majority of scientific packages, and <a href="https://www.anaconda.com/download" target="_blank">click here</a> to see it.</li>
    <li>Download and installation of Anaconda is highly recommended.</li>
    <li>After installation of Anaconda, hopefully you will hardly need any other package.</li>
    <li>Don't download and install Python from PSF.</li>
  </ul>
</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">6. Python Working Environments</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul type="list-style-type:disc">
    <li>Since Python is free and therefore multiple working environments exist for working in Python and some of them are given below.</li>
    <div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
      <ul style="list-style-type:circle">
        <li><strong>Interactive mode:</strong> gives outputs for every line/cell</li>
        <li><strong>Non-interactive mode:</strong> outputs after completion of code by calling Python interpreter</li>
        <li><strong>Integrated Development Environment:</strong> everything under one umbrella</li>
        <li><strong>Text and console arrangement:</strong> code in text editor run in console by calling Python interpreter</li>
      </ul>
    </div>
  </ul>
</div>

<br>
<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0203.png" width="80%" alt="envs"><br><br>
  <figcaption style="font-size: 52px; line-height: 2.0; text-align: center;"><strong>Figure 3.</strong> Summary of Python working environments.</figcaption>
</figure>
<br>

<br>
<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0204.png" width="90%" alt="envs1"><br><br>
  <figcaption style="font-size: 52px; line-height: 2.0; text-align: center;"><strong>Figure 4.</strong> Interactive text and console session: Python interpreter.</figcaption>
</figure><br>

<br>
<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0205.png" width="90%" alt="envs2"><br><br>
  <figcaption style="font-size: 52px; line-height: 2.0; text-align: center;"><strong>Figure 5.</strong> Interactive text and console session: IPython.</figcaption>
</figure><br>

<br>
<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0206.png" width="90%" alt="envs3"><br><br>
  <figcaption style="font-size: 52px; line-height: 2.0; text-align: center;"><strong>Figure 6.</strong> Interactive IDE: Jupyter Notebook.</figcaption>
</figure><br>

<br>
<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0207.png" width="90%" alt="envs7"><br><br>
  <figcaption style="font-size: 52px; line-height: 2.0; text-align: center;"><strong>Figure 7.</strong> Interactive IDE: Google Colab.</figcaption>
</figure><br>

<br>
<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0208.png" width="90%" alt="envs8"><br><br>
  <figcaption style="font-size: 52px; line-height: 2.0; text-align: center;"><strong>Figure 8.</strong> Non-interactive text and console session: IDLE code editor.</figcaption>
</figure><br>

<br>
<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0209.png" width="90%" alt="envs9"><br><br>
  <figcaption style="font-size: 52px; line-height: 2.0; text-align: center;"><strong>Figure 9.</strong> Non-interactive text and console session: IDLE console.</figcaption>
</figure><br>

<br>
<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0210.png" width="90%" alt="envs10"><br><br>
  <figcaption style="font-size: 52px; line-height: 2.0; text-align: center;"><strong>Figure 10.</strong> Non-interactive text and console session: Kate text editor.</figcaption>
</figure><br>

<br>
<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0211.png" width="90%" alt="envs11"><br><br>
  <figcaption style="font-size: 52px; line-height: 2.0; text-align: center;"><strong>Figure 11.</strong> Non-interactive text and console session: Linux Konsole/Terminal.</figcaption>
</figure><br>

<br>
<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0212.png" width="90%" alt="envs12"><br><br>
  <figcaption style="font-size: 52px; line-height: 2.0; text-align: center;"><strong>Figure 12.</strong> Non-interactive IDE: Spyder.</figcaption>
</figure><br>

<br>
<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0213.png" width="90%" alt="envs13"><br><br>
  <figcaption style="font-size: 52px; line-height: 2.0; text-align: center;"><strong>Figure 13.</strong> Non-interactive IDE: Visual Studio Code.</figcaption>
</figure><br>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">7. Summary</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Python is a free programming language licensed under PSF which can be downloaded, distributed, installed, and used free (libre).</li>
    <li>Python packages are released by PyPI.</li>
    <li>Anaconda provides python with several packages incorporated which is very useful specially for the newbies.</li>
    <li>Python has different working environments including interactive mode, text and terminal, and IDE arrangements.</li>
    <li>The installer provided by Anaconda and Spyder IDE (because it has MATLAB like layout as well) and Visual Studio Code are highly recommended for scientific computing.</li>
  </ul>
</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">8. Exercises</h2>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Exercise 1</h3>

<p style="font-size: 52px; line-height: 2.0; text-align: left; padding-left: 95px;"><strong>a) </strong>List down ten packages from PyPI and describe their purpose of use.</p>

<p style="font-size: 52px; line-height: 2.0; text-align: left; padding-left: 95px;"><strong>b) </strong>List down ten packages from Anaconda used in scientific computing and data science. Also describe their purpose of use.</p>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Exercise 2</h3>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;">Briefly describe the main functionalities of:</p>

<p style="font-size: 52px; line-height: 2.0; text-align: left; padding-left: 95px;"><strong>a) </strong>Spyder IDE</p>

<p style="font-size: 52px; line-height: 2.0; text-align: left; padding-left: 95px;"><strong>b) </strong>Visual Studio Code IDE</p>

<p style="font-size: 52px; line-height: 2.0; text-align: left; padding-left: 95px;"><strong>c) </strong>Jupyter Notebook</p>
