<h1 style="color: #228B22; text-align: center; line-height: 2.0;">📈 Fundamentals of Programming (CS-114)</h1>
<br>
<h1 style="color: #0000FF; text-align: center; line-height: 2.0;">📝 Prelude</h1>
<br>
<h1 style="color: #FF0000; text-align: center; line-height: 2.0;">🎓 Dr. Aamir Alaud Din</h1>
<br>
<h1 style="color: #228B22; text-align: center; line-height: 2.0;">🗓️ August 14, 2025</h1>
<br>

<h2 style="color: black; background-color: #FF8C00; border-left: 20px solid #FF0000; border-radius: 10px; line-height: 2.0; padding-left: 10px;">Contents</h2>
<div style="font-weight: bold; font-size: 24px; line-height: 2.0; padding-left: 40px;">
  <ol type="1">
    <li>About the Instructor</li>
    <li>About the Course</li>
    <li>Lectures Format</li>
    <li>Assessments</li>
    <li>Attendance</li>
    <li>Class Rules</li>
    <li>Books</li>
    <li>Key to Success</li>
  </ol>
</div>

<h2 style="color: black; background-color: #FF8C00; border-left: 20px solid #FF0000; border-radius: 5px; line-height: 2.0; padding-left: 10px;">1. About the Instructor</h2>
<div style="line-height: 2.0;">
  <ul style="list-style-type:disc">
    <li><strong>Name: </strong>Aamir Alaud Din</li>
    <li><strong>Highest Qualification: </strong>PhD</li>
    <li><strong>Specialized Teaching Areas: </strong>Computational</li>
    <ul style="list-style-type:circle">
      <li>Computer Programming</li>
      <li>Differential Equations</li>
      <li>Linear Algebra</li>
      <li>Probability and Statistics</li>
      <li>Numerical Methods</li>
      <li>Fluid Mechanics</li>
      <li>Thermodynamics</li>
      <li>Multivariate Analysis</li>
      <li>Machine Learning</li>
      <li>Deep Learning</li>
      <li>Artificial Intelligence</li>
    </ul>
  </ul>
</div>

<h2 style="color: black; background-color: #FF8C00; border-left: 20px solid #FF0000; border-radius: 5px; line-height: 2.0; padding-left: 10px;">2. About the Course</h2>
<div style="line-height: 2.0;">
  <ul style="list-style-type:disc">
    <li>Introductory course</li>
    <li>No past programming experience</li>
    <li>No prerequisite except basic mathematics</li>
    <li><strong>Course Title: </strong>Fundamentals of Programming</li>
    <li><strong>Course Code: </strong>CS-114</li>
    <li><strong>Credit Hourse: </strong>(2, 1)</li>
    <ul style="list-style-type:circle">
      <li>Theory: 2</li>
      <li>Laboratory: 1</li>
      <li>Total: 3</li>
    </ul>
    <li><strong>Contact Hours: </strong>(2, 3)</li>
    <ul style="list-style-type:circle">
      <li>Theory: 2</li>
      <li>Laboratory: 3</li>
      <li>Total: 5</li>
    </ul>
    <li><strong>Objectives: </strong>Objectives of the course are to</li>
    <ul style="list-style-type:circle">
      <li>Develop comprehensive knowledge of fundamental principles, concepts, and constructs of Python programming language</li>
      <li>Develop competencies in the design, coding, and debugging of computer programs</li>
    </ul>
  </ul>
</div>

<h2 style="color: black; background-color: #FF8C00; border-left: 20px solid #FF0000; border-radius: 5px; line-height: 2.0; padding-left: 10px;">3. Lecture Format</h2>
<div style="line-height: 2.0;">
  <ol style="1">
    <li>Contents</li>
    <li>Recap</li>
    <li>Objectives</li>
    <li>The Why Section</li>
    <li>Subtopics</li>
    <li>Summary</li>
    <li>Exercises</li>
  </ol>
</div>

<h2 style="color: black; background-color: #FF8C00; border-left: 20px solid #FF0000; border-radius: 5px; line-height: 2.0; padding-left: 10px;">4. Assessments</h2>
<div style="line-height: 2.0;">
  <ul type="list-style-type:disc">
    <li><strong>Theory</strong></li>
    <ul style="list-style-type:circle">
      <li>Quizzes: 4</li>
      <li>Homeworks: 4</li>
      <li>Mid Semester Exam: 1</li>
      <li>End Semester Exam: 1</li>
    </ul>
    <li><strong>Laboratory</strong></li>
    <ul style="list-style-type:circle">
    <li>Quizzes: 2</li>
    <li>Homeworks: 2</li>
    <li>Mid Semester Exam: 1</li>
    <li>End Semester Exam: 1</li>
    </ul>
    <li><strong>Weightage</strong></li>
    <ul style="list-style-type:circle">
      <li><strong>Theory</strong></li>
      <ul style="list-style-type:square">
      <li>Quizzes: 15%</li>
      <li>Homeworks: 10%</li>
      <li>Mid Semester Exam: 25%</li>
      <li>End Semester Exam: 50%</li>
      </ul>
      <li><strong>Laboratory</strong></li>
      <ul style="list-style-type:square">
        <li>Lab Work/Psychomotor Assessment/Lab Reports: 50-70%</li>
        <li>Lab Project/Open-ended Lab Project/Assignment/Quiz: 10-20%</li>
        <li>Final Assessment/Mid Semester Assessment (Written, viva, hands-on experimentation, group task): 20-30%</li>
      </ul>
    </ul>
  </ul>
</div>

<h3 style="color: #FF0000; font-weight: bold; line-height: 2.0;">NOTE:</h3>
<p style="color: #FF0000; line-height: 2.0;">Use of mobile phones is not allowed in any assessment. Exchange of calculators is not allowed, bring your calculator.</p>

<h2 style="color: black; background-color: #FF8C00; border-left: 20px solid #FF0000; border-radius: 5px; line-height: 2.0; padding-left: 10px;">5. Attendance</h2>
<div style="line-height: 2.0;">
  <ul type="list-style-type:disc">
    <li>75% Attendance for ESE</li>
    <li>Leverage of 25% for emergencies</li>
    <li>Attend to understand</li>
    <li>Absentees lead to low grades</li>
  </ul>
</div>

<h2 style="color: black; background-color: #FF8C00; border-left: 20px solid #FF0000; border-radius: 5px; line-height: 2.0; padding-left: 10px;">6. Class Rules</h2>
<div style="line-height: 2.0;">
  <ul type="list-style-type:disc">
    <li>No cell phones (50% marks deduction in quizzes)</li>
    <li>No discussion/gossips (50% marks deduction in quizzes)</li>
    <li>Attendance policy of 15 minutes</li>
    <li>Open to relevant questions</li>
    <li>Eating drinking without noise (no lunch please)</li>
    <li>Open door policy for student contact hours</li>
  </ul>
</div>

<h2 style="color: black; background-color: #FF8C00; border-left: 20px solid #FF0000; border-radius: 5px; line-height: 2.0; padding-left: 10px;">7. Books</h2>
<figure>
  <img src="../images/0001.png" width="100%" alt="hill">
  <figcaption style="text-align: center;"><strong>Figure 1.</strong> A good starter for newbies.</figcaption>
</figure><br>
<figure>
  <img src="../images/0002.png" width="100%" alt="langtangen">
  <figcaption style="text-align: center;"><strong>Figure 2.</strong> Detailed and gives mastery on material.</figcaption>
</figure><br>

<h2 style="color: black; background-color: #FF8C00; border-left: 20px solid #FF0000; border-radius: 5px; line-height: 2.0; padding-left: 10px;">8. Key to Success</h2>
<div style="line-height: 2.0;">
  <ul type="list-style-type:disc">
    <li>Listening and understanding silently</li>
    <li>Relevant questioning</li>
    <li>Reading books</li>
    <li>Preparing notes</li>
    <li>Thinking algorithms</li>
    <li>Writing and debugging programs</li>
    <li><span style="color: #FF0000;">PRACTICE, PRACTICE, AND PRACTICE!!!</span></li>
  </ul>
</div>